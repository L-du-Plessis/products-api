PRODUCTS REST API README
------------------------

NOTES
-----
* The API is developed in Laravel and tested on a MySQL database. 
  It uses Laravel Passport for authentication.
  
SETUP
-----
* The MySQL database details need to be inserted in the "/.env" file.
* Run Laravel migrations to create the tables.

ENDPOINTS
---------
ENDPOINT                                    DESCRIPTION                         RETURN
get('/products')                            List all products                   products array
post('/products')                           Create a product                    product object and HTTP code 201 (Object created)
get('/products/{product}')                  Retrieve "                          product object
put('/products/{product}')                  Update "                            product object and HTTP code 200 (OK)
delete('/products/{product}')               Delete "                            HTTP code 204 (No content)

get('/products/{category}/category')        Retrieve products in a category     products array
put('/products/{oldcategory}/{category}')   Update products in a category       products array and HTTP code 200 (OK)

get('/categories')                          List all categories                 categories array
post('/categories')                         Create a category                   category object and HTTP code 201 (Object created)
get('/categories/{category}')               Retrieve "                          category object
put('/categories/{category}')               Update "                            category object and HTTP code 200 (OK)
delete('/categories/{category}')            Delete "                            HTTP code 204 (No content)



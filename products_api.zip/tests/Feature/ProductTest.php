<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Product;

class ProductTest extends TestCase
{
    /** @test */
    /*
    public function it_will_show_all_products()
    {
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->get('/api/products');

        $response->assertStatus(200);
        
        //dd($response->json()[0]);

        $response->assertJsonCount(2, 0);
    }
    */
    
    /** @test */
    /*
    public function it_will_create_products()
    {
        //$this->withoutExceptionHandling();
        
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->post('/api/products', [
            'name' => 'Test Product',
            'category_id' => 1,
            'sku' => 'SKU003',
            'price' => 15.00,
            'quantity' => 1
        ]);

        $response->assertStatus(201);

        $this->assertDatabaseHas('products', [
            'name' => 'Test Product'
        ]);
    }
    */
    
    /** @test */
    /*
    public function it_will_show_a_product()
    {
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->get('/api/products/1');
        
        //dd($response->json());

        $response->assertStatus(200);
        
        $product = $response->json();
        
        $response->assertJson($product);
    }
    */
    
    /** @test */
    /*
    public function it_will_update_a_product()
    {
        //$this->withoutExceptionHandling();
        
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->put('/api/products/1', [
            'name' => 'Updated product',
            'category_id' => 1,
            'sku' => 'SKU001',
            'price' => 20.00,
            'quantity' => 5
        ]);

        $response->assertStatus(200);

        $this->assertDatabaseHas('products', [
            'name' => 'Updated Product'
        ]);
    }
    */
    
    /** @test */
    /*
    public function it_will_delete_a_product()
    {
        //$this->withoutExceptionHandling();
        
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->delete('/api/products/2');

        $response->assertStatus(204);
        
        $this->assertDatabaseMissing('products', [
            'id' => 2
        ]);
    }
    */
    
    /** @test */
    /*
    public function it_will_show_all_products_in_a_category()
    {
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->get('/api/products/1/category');

        $response->assertStatus(200);
        
        //dd($response->json());

        $response->assertJsonCount(2, 0);
    }
    */
    
    /** @test */
    /*
    public function it_will_update_products_in_a_category()
    {
        //$this->withoutExceptionHandling();
        
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->put('/api/products/1/2', []);

        $response->assertStatus(200);

        $this->assertDatabaseHas('products', [
            'category_id' => 2
        ]);
    }
    */
}

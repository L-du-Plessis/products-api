<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Category;

class CategoryTest extends TestCase
{
    /** @test */
    /*
    public function it_will_show_all_categories()
    {
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->get('/api/categories');

        $response->assertStatus(200);
        
        //dd($response->json()[0]);

        $response->assertJsonCount(1, 0);
    }
    */
    
    /** @test */
    /*
    public function it_will_create_categories()
    {
        $this->withoutExceptionHandling();
        
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->post('/api/categories', [
            'name' => 'Test Category'
        ]);

        $response->assertStatus(201);

        $this->assertDatabaseHas('categories', [
            'name' => 'Test Category'
        ]);
    }
    */
    
    /** @test */
    /*
    public function it_will_show_a_category()
    {
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->get('/api/categories/1');
        
        //dd($response->json());

        $response->assertStatus(200);
        
        $category = $response->json();
        
        $response->assertJson($category);
    }
    */
    
    /** @test */
    /*
    public function it_will_update_a_category()
    {
        //$this->withoutExceptionHandling();
        
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->put('/api/categories/2', [
            'name' => 'Updated Category'
        ]);

        $response->assertStatus(200);

        $this->assertDatabaseHas('categories', [
            'name' => 'Updated Category'
        ]);
    }
    */
    
    /** @test */
    /*
    public function it_will_delete_a_category()
    {
        //$this->withoutExceptionHandling();
        
        $this->actingAs(factory('App\User')->create(), 'api');
        
        $response = $this->delete('/api/categories/1');

        $response->assertStatus(204);
        
        $this->assertDatabaseMissing('categories', [
            'id' => 1
        ]);
    }
    */
}

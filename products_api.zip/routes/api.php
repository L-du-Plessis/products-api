<?php

use Illuminate\Http\Request;

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::middleware(['auth:api'])->group(function () {
    // List all products
    // Create, retrieve, update, delete a product
    Route::get('/products', 'ProductController@index');
    Route::post('/products', 'ProductController@store');
    Route::get('/products/{product}', 'ProductController@show');
    Route::put('/products/{product}', 'ProductController@update');
    Route::delete('/products/{product}', 'ProductController@destroy');

    // Retrieve and update products in a category
    Route::get('/products/{category}/category', 'ProductController@all_category');
    Route::put('/products/{oldcategory}/{category}', 'ProductController@update_category');

    // List all categories
    // Create, retrieve, update, delete a category
    Route::get('/categories', 'CategoryController@index');
    Route::post('/categories', 'CategoryController@store');
    Route::get('/categories/{category}', 'CategoryController@show');
    Route::put('/categories/{category}', 'CategoryController@update');
    Route::delete('/categories/{category}', 'CategoryController@destroy');
});

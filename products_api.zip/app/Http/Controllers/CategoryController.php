<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class CategoryController extends Controller
{
    /**
     * List all categories.
     *
     * @return categories array
     */
    public function index()
    {
        return Category::orderBy('name')->get();
    }

    /**
     * Create a category.
     *
     * @return category object and HTTP code 201 (Object created)
     */
    public function store()
    {
        $attributes = request()->validate([
            'name' => 'required'
        ]);

        $category = auth()->user()->category()->create($attributes);
        
        return response()->json($category, 201);
    }
    
    /**
     * Retrieve a category.
     *
     * @return category object
     */
    public function show(Category $category)
    {
        return $category;
    }
    
    /**
     * Update a category.
     *
     * @return category object and HTTP code 200 (OK)
     */
    public function update(Category $category)
    {
        $attributes = request()->validate([
            'name' => 'required'
        ]);
        $attributes['user_id'] = auth()->id();

        $category->update($attributes);
            
        return response()->json($category, 200);
    }
    
    /**
     * Delete a category.
     *
     * @return HTTP code 204 (No content)
     */
    public function destroy(Category $category)
    {
        $category->delete();
        
        return response()->json(null, 204);
    }
}

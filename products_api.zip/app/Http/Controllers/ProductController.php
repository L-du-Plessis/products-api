<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;

class ProductController extends Controller
{
    /**
     * List all products.
     *
     * @return products array
     */
    public function index()
    {
        return Product::orderBy('name')->get();
    }

    /**
     * Create a product.
     *
     * @return product object and HTTP code 201 (Object created)
     */
    public function store()
    {
        $attributes = request()->validate([
            'name' => 'required',
            'category_id' => 'required',
            'sku' => 'required',
            'price' => 'required',
            'quantity' => 'required'
        ]);
        
        $product = auth()->user()->product()->create($attributes);
        
        return response()->json($product, 201);
    }
    
    /**
     * Retrieve a product.
     *
     * @return product object
     */
    public function show(Product $product)
    {
        return $product;
    }
    
    /**
     * Update a product.
     *
     * @return product object and HTTP code 200 (OK)
     */
    public function update(Product $product)
    {
        $attributes = request()->validate([
            'name' => 'required',
            'category_id' => 'required',
            'sku' => 'required',
            'price' => 'required',
            'quantity' => 'required'
        ]);
        $attributes['user_id'] = auth()->id();

        $product->update($attributes);
        
        return response()->json($product, 200);
    }
    
    /**
     * Delete a product.
     *
     * @return HTTP code 204 (No content)
     */
    public function destroy(Product $product)
    {
        $product->delete();
        
        return response()->json(null, 204);
    }
    
    /**
     * List all products in a category.
     *
     * @return products array
     */
    public function all_category($category_id)
    {
        return Product::where('category_id', $category_id)
                        ->orderBy('name')
                        ->get();
    }

    /**
     * Update all products in a category.
     *
     * @return products array and HTTP code 200 (OK)
     */
    public function update_category($oldcategory, $category)
    {
        $products = Product::where('category_id', $oldcategory)
                            ->update(['category_id' => $category]);
            
        return response()->json($products, 200);
    }
}
